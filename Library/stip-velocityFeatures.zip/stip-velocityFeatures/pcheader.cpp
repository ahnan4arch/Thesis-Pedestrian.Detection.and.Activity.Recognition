
// IN VC++ :
// pcheader.cpp : source file that includes just the standard includes
// $projectname.pch will be the pre-compiled header
// pcheader.obj will contain the pre-compiled type information


#include "pcheader.h"

