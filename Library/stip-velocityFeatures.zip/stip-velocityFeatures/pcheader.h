/* precompiled header 
 include headers or project specific include files that are used frequently, but
 are changed infrequently
*/


//#define USE_CVCAM

//#ifdef USE_PCH
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cassert>

#include <string>
#include <iostream>
#include <fstream>
#include <vector>
//#include <hash_map>
#include <algorithm>
#include <functional>


#include "cv.h"
#include "highgui.h"


//#endif


